var OMDB_URL = "http://www.omdbapi.com/?t=";
var example = "frozen";
var currentURL = "wow";
var newStr;
var newerStr;
document.addEventListener('DOMContentLoaded', function() {

    chrome.tabs.query({'active': true, 'lastFocusedWindow': true}, function (tabs) {
    currentURL = tabs[0].url;
    newStr = currentURL.match("watch-(.*)-online");
    newerStr = newStr[1].replace(/-/g, " ");
   // alert(newerStr);
 
    var getRatingButton = document.getElementById('getRating');
   // getRatingButton.addEventListener('click', function() {
    var display = document.getElementById('display');
    var searchUrl = OMDB_URL+newerStr+"&y=&plot=short&r=json";
    var xhr = new XMLHttpRequest();
    xhr.open("GET", searchUrl, false);
    xhr.send();
    var resultJSON = xhr.responseText;
    var jsonResponse = JSON.parse(resultJSON);
    var val = jsonResponse["imdbRating"];
    if(val < 6)
      display.value = "rating = "+val+" :(";
    else
      display.value = "rating = "+val+" :D"
  //display.value = newStr;
});
}, false);


